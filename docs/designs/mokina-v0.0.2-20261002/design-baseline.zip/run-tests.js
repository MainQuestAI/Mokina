#!/usr/bin/env node
// Mokina V0.0.2 统一测试入口：一次跑完全部回归测试。
// 用法：node run-tests.js   （等价于 node --test tests/）
const { spawnSync } = require('node:child_process');
const path = require('node:path');

const dir = __dirname;
const files = [
  'tests/composer-material.test.js',
  'tests/glass-cleanup.test.js',
  'tests/pointer-path.test.js',
].map(f => path.join(dir, f));

const result = spawnSync(process.execPath, ['--test', ...files], { stdio: 'inherit' });
process.exit(result.status == null ? 1 : result.status);
