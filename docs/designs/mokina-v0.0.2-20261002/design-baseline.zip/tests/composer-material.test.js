const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
function environment(){
 const events={},media={},frames=new Map(),timers=new Map(),classes=new Set(['material-stage-one']);
 const measured=[],planes=[];let serial=0,resize;
 function plane(name){const values=new Map();const el={isConnected:true,dataset:{glass:'toolbar'},style:{setProperty:(k,v)=>values.set(k,v),removeProperty:k=>values.delete(k)},closest:()=>true,contains:()=>false,getBoundingClientRect(){measured.push(name);return {width:1,height:1,left:0,top:0}},values};planes.push(el);return el;}
 const context={window:{},document:{body:{classList:{contains:k=>classes.has(k),toggle(k,on){on?classes.add(k):classes.delete(k)}}},querySelectorAll:()=>planes,addEventListener:(n,f)=>events[n]=f},matchMedia(q){return media[q]||=( {matches:false,addEventListener(n,f){this.change=f}})},ResizeObserver:class{constructor(f){resize=f}observe(){}disconnect(){}},getComputedStyle:()=>({borderTopLeftRadius:'16px'}),requestAnimationFrame:f=>{frames.set(++serial,f);return serial},cancelAnimationFrame:id=>frames.delete(id),setTimeout:f=>{timers.set(++serial,f);return serial},clearTimeout:id=>timers.delete(id),addEventListener:(n,f)=>events[n]=f};
 vm.runInNewContext(fs.readFileSync(require.resolve('../glass-material.js'),'utf8'),context);
 return {events,media,frames,timers,classes,measured,plane,glass:context.window.MokinaGlass,resize:entries=>resize(entries)};
}
test('manual transparency cancels composer highlight and restores after leaving',()=>{
 const e=environment(),p=e.plane('composer'),move=()=>e.events.pointermove({target:{closest:()=>p},clientX:.5,clientY:.5});
 move();for(const [id,f] of e.frames){e.frames.delete(id);f()};assert.equal(p.values.get('--light-x'),'50%');
 move();e.classes.add('reduce-transparency');e.glass.preferenceChanged();assert.equal(e.frames.size,0);assert.equal(p.values.size,0);move();assert.equal(e.frames.size,0);
 e.classes.delete('reduce-transparency');e.glass.preferenceChanged();move();assert.equal(e.frames.size,1);e.events.pointerout({target:{closest:()=>p},relatedTarget:null});assert.equal(e.frames.size,0);assert.equal(p.values.size,0);
});
test('successive resize deliveries retain both composer and toolbar until flush',()=>{
 const e=environment(),a=e.plane('composer'),b=e.plane('toolbar');e.glass.refresh();e.measured.length=0;
 e.resize([{target:a}]);e.resize([{target:b}]);assert.equal(e.timers.size,1);
 for(const [id,f] of e.timers){e.timers.delete(id);f()};assert.deepEqual(e.measured,['composer','toolbar']);
 e.measured.length=0;e.resize([{target:a}]);e.events.pagehide();assert.equal(e.timers.size,0);assert.deepEqual(e.measured,[]);
});
test('composer height reserves matching message and keyboard scroll clearance',()=>{
 let resize,disconnects=0;const events={},vars=new Map(),body={style:{setProperty:(k,v)=>vars.set(k,v)}};
 const target={closest:()=>({querySelector:()=>body}),getBoundingClientRect:()=>({height:210.2})};
 const c={window:{},ResizeObserver:class{constructor(f){resize=f}observe(){}disconnect(){disconnects++}},document:{querySelectorAll:()=>[target]},addEventListener:(n,f)=>events[n]=f};
 vm.runInNewContext(fs.readFileSync(require.resolve('../design-system/mokina-layout.js'),'utf8'),c);c.window.MokinaLayout.refresh();resize([{target}]);assert.equal(body.style.paddingBottom,'235px');assert.equal(vars.get('--composer-clearance'),'235px');events.pagehide();assert.equal(disconnects,1);
});
