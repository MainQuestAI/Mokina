const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

function environment() {
  const handlers = {}, media = {};
  const values = new Map();
  const plane = {
    isConnected: true,
    dataset: { glass: 'toolbar' },
    style: { setProperty(k,v){ values.set(k,v); }, removeProperty(k){ values.delete(k); } },
    getBoundingClientRect(){ return { left: 0, top: 0, width: 200, height: 80 }; }
  };
  const frames = new Map(); let nextFrame = 1, canceled = 0;
  const context = {
    window: {},
    document: {
      body: { classList: { contains(){ return false; }, toggle(){} } },
      addEventListener(name,fn){ handlers[name]=fn; },
      querySelectorAll(){ return [plane]; }
    },
    matchMedia(query){
      return media[query] ||= { matches:false, addEventListener(name,fn){ this.changed=fn; } };
    },
    requestAnimationFrame(fn){ const id=nextFrame++; frames.set(id,fn); return id; },
    cancelAnimationFrame(id){ if(frames.delete(id)) canceled++; },
    addEventListener(name,fn){ handlers[name]=fn; },
    setTimeout, clearTimeout,
    CSS: { supports(){ return true; } }
  };
  vm.runInNewContext(fs.readFileSync(require.resolve('../glass-material.js'),'utf8'),context);
  const glass=context.window.MokinaGlass;
  const event=(x,y)=>({ target:{ closest(){ return plane; } }, clientX:x, clientY:y });
  return {
    handlers, frames, values, glass,
    move: (x, y) => handlers.pointermove(event(x, y)),
    flush() { for (const [id, fn] of frames) { frames.delete(id); fn(); } },
    motion(matches) {
      media['(prefers-reduced-motion: reduce)'].matches = matches;
      media['(prefers-reduced-motion: reduce)'].changed();
    },
    get canceled() { return canceled; }
  };
}

function highlightedWithPendingFrame() {
  const e = environment();
  e.move(80, 30);
  e.flush();
  e.move(150, 40);
  assert.equal(e.frames.size, 1);
  return e;
}

test('连续指针移动共用一个待执行帧', () => {
  const e = environment();
  e.move(20, 20);
  e.move(80, 30);
  assert.equal(e.frames.size, 1);
});

test('执行帧使用最后一次指针位置更新高光', () => {
  const e = environment();
  e.move(20, 20);
  e.move(80, 30);
  e.flush();
  assert.equal(e.values.get('--light-x'), '40%');
});

test('启用减少动态取消待执行帧', () => {
  const e = highlightedWithPendingFrame();
  e.motion(true);
  assert.equal(e.frames.size, 0);
  assert.equal(e.canceled, 1);
});

test('启用减少动态清除已有高光', () => {
  const e = highlightedWithPendingFrame();
  e.motion(true);
  assert.equal(e.values.has('--light-x'), false);
});

test('取消后调试状态不再报告待执行帧', () => {
  const e = highlightedWithPendingFrame();
  e.motion(true);
  assert.equal(e.glass.debug().pendingFrame, false);
});

test('减少动态期间指针移动不会创建新帧', () => {
  const e = highlightedWithPendingFrame();
  e.motion(true);
  e.move(100, 50);
  assert.equal(e.frames.size, 0);
});

test('关闭减少动态后恢复指针帧调度', () => {
  const e = highlightedWithPendingFrame();
  e.motion(true);
  e.move(100, 50);
  e.motion(false);
  e.move(100, 50);
  assert.equal(e.frames.size, 1);
});

test('离开页面取消待执行帧并清除高光', () => {
  const e = highlightedWithPendingFrame();
  e.handlers.pagehide();
  assert.equal(e.frames.size, 0);
  assert.equal(e.values.has('--light-x'), false);
});
