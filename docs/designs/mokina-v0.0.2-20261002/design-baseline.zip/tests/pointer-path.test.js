const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ROOT=path.join(__dirname,'..');
const KEY='mokina-v002-design-state';

function boot(){
  const storage=new Map(),events={},timers=new Map();let serial=0;
  let html='',overlay='';
  const app={set innerHTML(v){html=v},get innerHTML(){return html}};
  const overlayRoot={set innerHTML(v){overlay=v},get innerHTML(){return overlay},querySelector(){return null},querySelectorAll(){return []}};
  const shellStyle={vars:new Map(),setProperty(k,v){this.vars.set(k,v)}};
  const document={
    getElementById(id){return id==='app'?app:id==='overlay-root'?overlayRoot:null},
    querySelector(sel){return sel==='.shell'?{style:shellStyle}:null},
    querySelectorAll(){return []},
    addEventListener(n,f){events[n]=f},
    body:{classList:{contains:()=>false,toggle(){}}},
  };
  const context={
    window:{},document,
    localStorage:{getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v))},
    structuredClone:globalThis.structuredClone,
    setTimeout:f=>{timers.set(++serial,f);return serial},
    clearTimeout:id=>timers.delete(id),
    console,
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(ROOT,'design-system/mokina-icons.js'),'utf8'),context);
  vm.runInContext(fs.readFileSync(path.join(ROOT,'app.js'),'utf8'),context);
  const api={events,storage,html:()=>html,overlay:()=>overlay,shellStyle,timers,
    persisted(){return JSON.parse(storage.get(KEY))},
    click(action,id){const b={dataset:{action,id}};events.click({target:{closest:sel=>sel==='[data-action]'?b:null}})},
    type(id,value){events.input({target:{id,value}})},
    keydown(key,target={classList:{contains:()=>false}}){let prevented=false;events.keydown({key,target,preventDefault(){prevented=true}});return prevented}};
  return api;
}
function dragHandle(events){
  const handle={attrs:{},listeners:{},setPointerCapture(){},addEventListener(n,f){this.listeners[n]=f},removeEventListener(n){delete this.listeners[n]},setAttribute(k,v){this.attrs[k]=String(v)}};
  events.pointerdown({target:{closest:sel=>sel==='.resize-handle'?handle:null},clientX:500,pointerId:1});
  return handle;
}

test('home → write goal → start work → workspace',()=>{
  const a=boot();
  a.click('go-home');assert.match(a.html(),/data-od-id="p01-home"/,'点击导航回到首页');
  a.click('home-start');assert.match(a.html(),/请先写下目标/,'空目标点击开始时给出提示');
  a.type('home-text','基于新品分析，制定国庆门店试饮方案');
  a.click('home-start');
  assert.match(a.html(),/data-od-id="p03-workspace"/,'开始工作后进入工作区');
  const s=a.persisted();assert.equal(s.projectId,'new-4');assert.equal(s.projects[0].status,'draft');
  assert.match(s.projects[0].name,/国庆/,'项目名取目标前 12 字');assert.match(s.projects[0].messages[0].text,/国庆门店试饮/,'完整目标保留在首条消息');
});

test('composer input stays reachable and send-draft runs the project',()=>{
  const a=boot();
  a.click('send-draft');assert.match(a.html(),/先写下要发送的内容/,'空草稿点击发送给出提示');
  a.type('project-draft','补充门店试饮的参与方式');
  a.click('send-draft');
  assert.match(a.html(),/正在模拟制作/,'发送后进入模拟运行');
  let p=a.persisted().projects.find(p=>p.id==='plan');
  assert.equal(p.status,'running');assert.equal(p.draft,'');assert.equal(p.messages.at(-1).who,'you');
  a.click('send-draft');assert.match(a.html(),/先写下要发送的内容/,'运行中草稿已清空，重复发送被拦截');
});

test('resize handle pointer drag clamps between 316 and 470',()=>{
  const a=boot();
  const h=dragHandle(a.events);
  assert.ok(h.listeners.pointermove&&h.listeners.pointerup,'指针按下后挂接移动与抬起');
  h.listeners.pointermove({clientX:900}); // 360+400 → 上限
  assert.equal(h.attrs['aria-valuenow'],'470');assert.equal(a.shellStyle.vars.get('--collab'),'470px');
  h.listeners.pointermove({clientX:100}); // 360-400 → 下限
  assert.equal(h.attrs['aria-valuenow'],'316');assert.equal(a.shellStyle.vars.get('--collab'),'316px');
  h.listeners.pointerup({});
  assert.equal(a.persisted().collabWidth,316,'松手后宽度持久化');
  assert.ok(!h.listeners.pointermove,'抬起后移动监听已移除');
  const prevented=a.keydown('ArrowRight',{classList:{contains:c=>c==='resize-handle'}});
  assert.ok(prevented,'键盘调宽阻止默认滚动');assert.equal(a.persisted().collabWidth,332,'方向键每次移动 16px');
});

test('revise entry → prompt guard → run → save → adopt bumps version',()=>{
  const a=boot();
  a.click('go-revise');
  assert.match(a.html(),/data-od-id="p05-revision"/,'工具条修订入口进入修订页');
  assert.equal(a.persisted().projects.find(p=>p.id==='plan').revisionBase,'v3','修订基础默认为当前正式稿');
  a.click('revision-start');assert.match(a.html(),/请先写明修订要求/,'空要求点击生成给出提示');
  a.type('revision-prompt','强调清晰的到店体验');
  a.click('revision-start');assert.match(a.html(),/候选生成中/,'生成候选任务启动');
  a.click('revision-finish');assert.match(a.html(),/正在保存候选/,'任务完成后进入保存');
  a.click('revision-save-finish');assert.match(a.html(),/候选已保存，正式稿尚未改变/,'候选就绪但正式稿未变');
  const before=a.persisted().projects.find(p=>p.id==='plan');
  assert.equal(before.current,'v3');assert.equal(before.revision.status,'ready');
  a.click('candidate-full');assert.match(a.overlay(),/完整候选版本/,'查看完整候选打开浮层');
  a.click('dialog-close');assert.equal(a.overlay(),'','关闭浮层后清空');
  a.click('revision-adopt');
  const after=a.persisted().projects.find(p=>p.id==='plan');
  assert.equal(after.current,'v4','采用后当前正式稿升版');
  assert.match(a.html(),/候选已采用为正式稿 v4/);
});
